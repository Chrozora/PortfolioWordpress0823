<?php
/**
 * Entry meta display
 *
 * @package Fotografie
 */

?>

<footer class="entry-footer">
	<?php fotografie_entry_footer(); ?>
</footer><!-- .entry-footer -->
