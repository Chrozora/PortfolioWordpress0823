<div class="site-social">
   <?php fotografie_social_menu(); ?>
</div><!-- .site-social -->
